var showApp = angular.module('showApp', [])

.controller('mainController', function($scope) {

  $scope.showSideBar = true;
  // $scope.showSearch = false;
  
});

